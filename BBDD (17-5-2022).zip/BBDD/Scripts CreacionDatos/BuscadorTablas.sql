SELECT table_name
FROM user_tables
WHERE table_name = 'USERS' 
OR table_name ='SHIP' 
OR table_name ='DEFENSE' 
OR table_name ='PLANET' 
OR table_name ='REGISTRE';